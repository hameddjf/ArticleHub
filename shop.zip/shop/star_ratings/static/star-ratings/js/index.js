module.exports = require('./src/ratings');
