from comment.signals.post_delete import *   # noqa
from comment.signals.post_migrate import *  # noqa
from comment.signals.post_save import * # noqa
